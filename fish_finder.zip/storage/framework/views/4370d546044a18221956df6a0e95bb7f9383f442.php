<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <title><?php echo e(request()->is('admin/login') ? 'Login | Fish Finder' : 'Register | Fish Finder'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <main class="w-full h-full flex justify-center">
        <?php echo e($slot); ?>

    </main>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
</body>
</html><?php /**PATH /home/jmsryn/Documents/Thesis/local/Fish_Finder/resources/views/layouts/auth.blade.php ENDPATH**/ ?>